import psycopg2

# Database connection parameters
db_params = {
    "host": "localhost",        # Database server address
    "database": "postgres", # Your database name
    "user": "postgres",     # Your database username
    "password": "",  # Your database password
    "port":"5433"
}

def fetch_data_from_db():
    try:
        # Connect to the PostgreSQL server
        connection = psycopg2.connect(**db_params)

        # Create a cursor to interact with the database
        cursor = connection.cursor()

        # Execute SQL query to fetch all records from the 'users' table
        cursor.execute("SELECT * FROM users")

        # Fetch all the records
        rows = cursor.fetchall()

        # Print the fetched data
        print("Users Data:")
        for row in rows:
            print(row)

    except Exception as error:
        print(f"Error fetching data: {error}")
    finally:
        # Close the cursor and connection
        if cursor:
            cursor.close()
        if connection:
            connection.close()

# Call the function to fetch data from the database
fetch_data_from_db()
