from sqlalchemy import create_engine, Column, Integer, String, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship


# Define the base class for our ORM model
Base = declarative_base()
# ORM Object Relational Mapping: sqlalchemy
# Define the User table model
class User(Base):
    __tablename__ = 'users'  # Name of the table in the database

    id = Column(Integer, primary_key=True)
    username = Column(String)
    email = Column(String)

    # Relationship to the Profile table (One-to-One or One-to-Many)
    profile = relationship("Profile", back_populates="user", uselist=False)

    def __repr__(self):
        return f"<User(id={self.id}, name={self.username}, email={self.email})>"

# Define the Profile table model
class Profile(Base):
    __tablename__ = 'profiles'

    id = Column(Integer, primary_key=True)
    bio = Column(String)
    user_id = Column(Integer, ForeignKey('users.id'))

    # Relationship to the User table
    user = relationship("User", back_populates="profile")

    def __repr__(self):
        return f"<Profile(id={self.id}, bio={self.bio}, user_id={self.user_id})>"

# Configuration dictionary for database connection
db_params = {
    "host": "localhost",        # Database server address
    "database": "postgres",     # Your database name
    "user": "postgres",         # Your database username
    "password": "",             # Your database password
    "port": "5433"              # Your database port
}

# Construct the database URL using db_params
DATABASE_URL = f"postgresql+psycopg2://{db_params['user']}:{db_params['password']}@{db_params['host']}:{db_params['port']}/{db_params['database']}"

# Create an engine to connect to the PostgreSQL database
engine = create_engine(DATABASE_URL)

# Create a session to interact with the database
Session = sessionmaker(bind=engine)
session = Session()

# Create tables in the database (if they don't already exist)
Base.metadata.create_all(engine)

def fetch_data_from_db():
    try:
        # Perform a JOIN between User and Profile
        users_with_profiles = session.query(User, Profile).join(Profile, User.id == Profile.user_id).all()

        # Print the fetched users and their profiles
        print("Users and Profiles Data:")
        for user, profile in users_with_profiles:
            print(f"User: {user.username}, Email: {user.email}, Bio: {profile.bio}")
    except Exception as error:
        print(f"Error fetching data: {error}")
    finally:
        # Close the session
        session.close()

# Call the function to fetch data from the database
fetch_data_from_db()
